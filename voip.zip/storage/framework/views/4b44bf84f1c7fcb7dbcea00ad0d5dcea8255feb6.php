 <?php if (isset($component)) { $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\SidebarItem::class, ['title' => 'داشبورد','icon' => 'fas fa-tachometer-alt','route' => 'dashboard.customer.index']); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586)): ?>
<?php $component = $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586; ?>
<?php unset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($component)) { $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\SidebarItem::class, ['title' => 'ثبت درخواست خرید','icon' => 'fas fa-shopping-basket','route' => 'dashboard.customer.enquiries.create']); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586)): ?>
<?php $component = $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586; ?>
<?php unset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($component)) { $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\SidebarItem::class, ['title' => 'پیغام‌های شما','icon' => 'fas fa-envelope','route' => 'dashboard.conversations.index']); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586)): ?>
<?php $component = $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586; ?>
<?php unset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', \Rinvex\Subscriptions\Models\Plan::class)): ?>
     <?php if (isset($component)) { $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\SidebarItem::class, ['title' => 'پکیج‌ها','icon' => 'fas fa-box','route' => 'dashboard.plans.index']); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586)): ?>
<?php $component = $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586; ?>
<?php unset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/dashboard/customer/sidebar.blade.php ENDPATH**/ ?>