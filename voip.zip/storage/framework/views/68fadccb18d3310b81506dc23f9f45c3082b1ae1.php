
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('dashboard.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('hierarchy'); ?>
     <?php if (isset($component)) { $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\BreadcrumbItem::class, ['title' => 'داشبورد','route' => 'dashboard.admin.index']); ?>
<?php $component->withName('breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6)): ?>
<?php $component = $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6; ?>
<?php unset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\BreadcrumbItem::class, ['title' => 'افزودن شماره تلفن','route' => 'dashboard.admin.voip.create']); ?>
<?php $component->withName('breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6)): ?>
<?php $component = $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6; ?>
<?php unset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\BreadcrumbItem::class, ['title' => 'مدیریت شماره تلفن','route' => 'dashboard.admin.voip.manage']); ?>
<?php $component->withName('breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6)): ?>
<?php $component = $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6; ?>
<?php unset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('info')): ?>
    <div class="row">
        <div class="col-md-12">
            <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
        </div>
    </div>
<?php endif; ?>
    <div class="col-md-12">
         <?php if (isset($component)) { $__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Card::class, ['type' => 'info']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php if (isset($component)) { $__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardHeader::class, []); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>مدیریت شماره ها <?php if (isset($__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c)): ?>
<?php $component = $__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c; ?>
<?php unset($__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                 <?php if (isset($component)) { $__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardBody::class, []); ?>
<?php $component->withName('card-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <div class="box-body">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>پیش شماره</th>
                                <th>شماره تلفن</th>
                                <th>شهر</th>
                                <th>حذف</th>                               
                                <th>ویرایش</th>
                            </tr>
                            </thead>
                                <tbody>
                             <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->benum); ?></td>
                                    <td><?php echo e($item->number); ?></td>
                                    <td><?php echo e($item->city); ?></td>
                                    <td>
                                    <a href="<?php echo e(route('dashboard.admin.voip.deletepost',['id'=>$item->id])); ?>" class="delete_post" ><i class="fa fa-fw fa-eraser"></i></a>                 
                                    </td>
                                    <td>
                                    <a href="<?php echo e(route('dashboard.admin.voip.updatepost',['id'=>$item->id])); ?>" class="edit_post" target="_blank"><i class="fas fa-edit"></i></a>
                                    </td>
                                </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>پیش شماره</th>
                                    <th>شماره تلفن</th>
                                    <th>شهر</th>
                                    <th>حذف</th>                                   
                                    <th>ویرایش</th>
                                </tr>
                                </tfoot>
                        </table>
                    </div>
                     <?php if (isset($__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225)): ?>
<?php $component = $__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225; ?>
<?php unset($__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                 <?php if (isset($component)) { $__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardFooter::class, []); ?>
<?php $component->withName('card-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <button type="submit" class="btn btn-success">ثبت شماره جدید</button>
                 <?php if (isset($__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d)): ?>
<?php $component = $__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d; ?>
<?php unset($__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>       
         <?php if (isset($__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff)): ?>
<?php $component = $__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff; ?>
<?php unset($__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\salar shirkhani work\Desktop\ahmadian\voip\resources\views/dashboard/admin/voip/manage.blade.php ENDPATH**/ ?>