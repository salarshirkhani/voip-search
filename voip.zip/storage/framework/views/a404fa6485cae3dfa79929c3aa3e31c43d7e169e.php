<option <?php echo e($attributes->merge([
    'value' => $value
])); ?>>
    <?php echo e($slot); ?>

</option>
<?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/components/form/select-item.blade.php ENDPATH**/ ?>