<div <?php echo e($attributes->merge(['class' => 'card-body'])); ?>>
    <?php echo e($slot); ?>

</div><?php /**PATH C:\xampp\htdocs\pol\b2b\storage\framework\views/c96b52be22329157586cd04c645b7ec034745d01.blade.php ENDPATH**/ ?>