
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('dashboard.owner.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('hierarchy'); ?>
     <?php if (isset($component)) { $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\BreadcrumbItem::class, ['title' => 'داشبورد','route' => 'dashboard.owner.index']); ?>
<?php $component->withName('breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6)): ?>
<?php $component = $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6; ?>
<?php unset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\BreadcrumbItem::class, ['title' => 'مشاهده شرکت','route' => 'dashboard.owner.companies.show']); ?>
<?php $component->withName('breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6)): ?>
<?php $component = $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6; ?>
<?php unset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
         <?php if (isset($component)) { $__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Card::class, ['type' => 'info']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php if (isset($component)) { $__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardHeader::class, []); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>شرکت <?php echo e($company->name); ?> <?php if (isset($__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c)): ?>
<?php $component = $__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c; ?>
<?php unset($__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardFooter::class, []); ?>
<?php $component->withName('card-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <?php if($company->type == 'product'): ?>
                    <a href="<?php echo e(route('dashboard.owner.products.create')); ?>" class="btn btn-success"><i class="fa fa-plus"></i> افزودن محصول</a>
                <?php else: ?>
                    <a href="<?php echo e(route('dashboard.owner.services.create')); ?>" class="btn btn-success"><i class="fa fa-plus"></i> افزودن سرویس</a>
                <?php endif; ?>
             <?php if (isset($__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d)): ?>
<?php $component = $__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d; ?>
<?php unset($__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff)): ?>
<?php $component = $__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff; ?>
<?php unset($__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/dashboard/owner/companies/show.blade.php ENDPATH**/ ?>