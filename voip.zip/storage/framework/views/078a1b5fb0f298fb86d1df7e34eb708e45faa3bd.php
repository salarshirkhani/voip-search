<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\pol\b2b\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>