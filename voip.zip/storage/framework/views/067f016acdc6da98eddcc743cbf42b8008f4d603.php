<div <?php echo e($attributes->merge(['class' => "alert" . (empty($type) ? '' : " alert-$type")])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/components/dashboard/alert.blade.php ENDPATH**/ ?>