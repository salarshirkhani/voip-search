<div <?php echo e($attributes->merge(["class" => "card" . (!empty($type) ? " card-$type" : "")])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/components/dashboard/card.blade.php ENDPATH**/ ?>