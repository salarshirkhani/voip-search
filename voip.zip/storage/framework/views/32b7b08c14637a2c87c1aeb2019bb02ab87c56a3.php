

<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="wrap-messages">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger"><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <div class="login100-pic js-tilt" data-tilt="">
        <img src="<?php echo e(asset("assets/auth/images/auth.webp")); ?>" alt="IMG">
    </div>

    <form class="login100-form validate-form" action="<?php echo e(route('login')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <span class="login100-form-title">
            ورود به حساب
					</span>

        <div class="wrap-input100 validate-input" data-validate="ایمیل اجباری است!">
            <input type="email" name="email" maxlength="100" class=" input100" placeholder="ایمیل" required=""
                   id="id_email" value="<?php echo e(old('email') ?? ''); ?>">
            <span class="focus-input100"></span>
            <span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
        </div>

-
        <div class="wrap-input100 validate-input" data-validate="رمزعبور اجباری است!">
            <input type="password" name="password" class=" input100" placeholder="کلمه‌عبور" id="id_password">
            <span class="focus-input100"></span>
            <span class="symbol-input100">
			    <i class="fa fa-lock" aria-hidden="true"></i>
			</span>
        </div>

        <div class="container-login100-form-btn">
            <button class="login100-form-btn">
                ورود
            </button>
        </div>

        
        
        
        
        
        
        
        

        <div class="text-center p-t-136">
            <a class="txt2" href="<?php echo e(route('register')); ?>">
                <?php echo e(__('میخواهید ثبت‌نام کنید؟')); ?>

                <i class="fa fa-long-arrow-left m-l-5" aria-hidden="true"></i>
            </a>
            <br>
            <a class="txt2" href="">
                <?php echo e(__('بازگشت')); ?>

                <i class="fa fa-long-arrow-left m-l-5" aria-hidden="true"></i>
            </a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp1\htdocs\ahmadian\voip\resources\views/auth/login.blade.php ENDPATH**/ ?>