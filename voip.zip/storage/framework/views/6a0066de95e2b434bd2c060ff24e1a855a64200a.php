<div class="form-group <?php echo e($width); ?>">
    <label for="input_<?php echo e($name); ?>"><?php echo e($label); ?></label>
    <input <?php echo e($attributes->merge([
        'id' => "input_$name",
        'type' => 'text',
        'name' => $name,
        'value' => $value,
        'class' => 'form-control' . ($errors->has($name) ? ' is-invalid' : '')
    ])); ?>>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/components/form/text-group.blade.php ENDPATH**/ ?>