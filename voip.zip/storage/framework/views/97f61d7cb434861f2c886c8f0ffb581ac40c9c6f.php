<div <?php echo e($attributes->merge(['class' => 'card-header'])); ?>>
    <h3 class="card-title"><?php echo e($slot); ?></h3>
    <?php echo e($down ?? ''); ?>

</div><?php /**PATH C:\xampp\htdocs\pol\b2b\storage\framework\views/d1cb8722b42fa8ded975cb0640aff04777ee10fd.blade.php ENDPATH**/ ?>