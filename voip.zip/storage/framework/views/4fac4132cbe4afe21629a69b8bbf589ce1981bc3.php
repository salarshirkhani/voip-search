
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('dashboard.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('hierarchy'); ?>
     <?php if (isset($component)) { $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\BreadcrumbItem::class, ['title' => 'داشبورد','route' => 'dashboard.customer.index']); ?>
<?php $component->withName('breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6)): ?>
<?php $component = $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6; ?>
<?php unset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\BreadcrumbItem::class, ['title' => 'ثبت درخواست خرید','route' => 'dashboard.customer.enquiries.create']); ?>
<?php $component->withName('breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6)): ?>
<?php $component = $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6; ?>
<?php unset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('dashboard.customer.enquiries.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
             <?php if (isset($component)) { $__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Card::class, []); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                 <?php if (isset($component)) { $__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardHeader::class, []); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>مشخصات درخواست <?php if (isset($__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c)): ?>
<?php $component = $__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c; ?>
<?php unset($__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                 <?php if (isset($component)) { $__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardBody::class, []); ?>
<?php $component->withName('card-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                     <?php if (isset($component)) { $__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\TextGroup::class, ['name' => 'title','label' => 'عنوان درخواست']); ?>
<?php $component->withName('text-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
<?php if (isset($__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44)): ?>
<?php $component = $__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44; ?>
<?php unset($__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                    <div class="form-row">
                         <?php if (isset($component)) { $__componentOriginalb654ee68fef70649a7b14fb54bee1e22ee402098 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectGroup::class, ['name' => 'type','label' => 'نوع درخواست','width' => 'col-md-5']); ?>
<?php $component->withName('select-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
                             <?php if (isset($component)) { $__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectItem::class, []); ?>
<?php $component->withName('select-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130)): ?>
<?php $component = $__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130; ?>
<?php unset($__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectItem::class, ['value' => 'product']); ?>
<?php $component->withName('select-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>تولیدی <?php if (isset($__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130)): ?>
<?php $component = $__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130; ?>
<?php unset($__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectItem::class, ['value' => 'service']); ?>
<?php $component->withName('select-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>خدماتی <?php if (isset($__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130)): ?>
<?php $component = $__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130; ?>
<?php unset($__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($__componentOriginalb654ee68fef70649a7b14fb54bee1e22ee402098)): ?>
<?php $component = $__componentOriginalb654ee68fef70649a7b14fb54bee1e22ee402098; ?>
<?php unset($__componentOriginalb654ee68fef70649a7b14fb54bee1e22ee402098); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                         <?php if (isset($component)) { $__componentOriginalb654ee68fef70649a7b14fb54bee1e22ee402098 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectGroup::class, ['name' => 'category','label' => 'دسته‌بندی موردنظر','width' => 'col-md-7']); ?>
<?php $component->withName('select-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                             <?php if (isset($component)) { $__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectItem::class, ['value' => '']); ?>
<?php $component->withName('select-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>بدون دسته‌بندی <?php if (isset($__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130)): ?>
<?php $component = $__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130; ?>
<?php unset($__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if (isset($component)) { $__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\SelectItem::class, ['value' => $category->id]); ?>
<?php $component->withName('select-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data-type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->type)]); ?><?php echo e($category->name); ?> <?php if (isset($__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130)): ?>
<?php $component = $__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130; ?>
<?php unset($__componentOriginal4e87be6026f3e1cf7b31c504188d30a729d5e130); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php if (isset($__componentOriginalb654ee68fef70649a7b14fb54bee1e22ee402098)): ?>
<?php $component = $__componentOriginalb654ee68fef70649a7b14fb54bee1e22ee402098; ?>
<?php unset($__componentOriginalb654ee68fef70649a7b14fb54bee1e22ee402098); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </div>

                     <?php if (isset($component)) { $__componentOriginal755a37bde2b9633abf5b2d849f80c57ea1328d21 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\TextareaGroup::class, ['name' => 'description','label' => 'توضیحات کامل']); ?>
<?php $component->withName('textarea-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['rows' => '10']); ?>
<?php if (isset($__componentOriginal755a37bde2b9633abf5b2d849f80c57ea1328d21)): ?>
<?php $component = $__componentOriginal755a37bde2b9633abf5b2d849f80c57ea1328d21; ?>
<?php unset($__componentOriginal755a37bde2b9633abf5b2d849f80c57ea1328d21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                 <?php if (isset($__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225)): ?>
<?php $component = $__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225; ?>
<?php unset($__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                 <?php if (isset($component)) { $__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardFooter::class, []); ?>
<?php $component->withName('card-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <button type="submit" class="btn btn-success">ثبت درخواست</button>
                 <?php if (isset($__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d)): ?>
<?php $component = $__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d; ?>
<?php unset($__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff)): ?>
<?php $component = $__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff; ?>
<?php unset($__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/dashboard/customer/enquiries/create.blade.php ENDPATH**/ ?>