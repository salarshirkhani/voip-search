<div <?php echo e($attributes->merge(['class' => 'card-footer'])); ?>>
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Users\salar shirkhani work\Desktop\ahmadian\voip\storage\framework\views/f88db91e177b8b370b1755ffe9de6878d7845e04.blade.php ENDPATH**/ ?>