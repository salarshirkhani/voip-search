<li class="nav-item">
    <?php if(!empty($route)): ?>
        <a href="<?php echo e(route($route, $routeParam)); ?>" class="nav-link <?php if(Route::current()->getName() == $route): ?> active <?php endif; ?>">
    <?php else: ?>
        <span class="nav-link">
    <?php endif; ?>
        <i class="nav-icon <?php echo e($icon); ?>"></i>
        <p>
            <?php echo e($title); ?>

        </p>
    <?php if(!empty($route)): ?>
        </a>
    <?php else: ?>
        </span>
    <?php endif; ?>
</li>
<?php /**PATH C:\Users\salar shirkhani work\Desktop\ahmadian\voip\resources\views/components/dashboard/sidebar-item.blade.php ENDPATH**/ ?>