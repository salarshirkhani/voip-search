
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('dashboard.owner.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('hierarchy'); ?>
     <?php if (isset($component)) { $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\BreadcrumbItem::class, ['title' => 'داشبورد','route' => 'dashboard.owner.index']); ?>
<?php $component->withName('breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6)): ?>
<?php $component = $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6; ?>
<?php unset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.session-alerts','data' => []]); ?>
<?php $component->withName('session-alerts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/dashboard/owner/index.blade.php ENDPATH**/ ?>