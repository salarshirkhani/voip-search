<?php if(Session::has('success')): ?>
     <?php if (isset($component)) { $__componentOriginal0ebe86c2aa149023011d5c698673811627439e8c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Alert::class, ['type' => 'success']); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php echo e(Session::get('success')); ?> <?php if (isset($__componentOriginal0ebe86c2aa149023011d5c698673811627439e8c)): ?>
<?php $component = $__componentOriginal0ebe86c2aa149023011d5c698673811627439e8c; ?>
<?php unset($__componentOriginal0ebe86c2aa149023011d5c698673811627439e8c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php endif; ?>
<?php if(Session::has('error')): ?>
     <?php if (isset($component)) { $__componentOriginal0ebe86c2aa149023011d5c698673811627439e8c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Alert::class, ['type' => 'danger']); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php echo e(Session::get('error')); ?> <?php if (isset($__componentOriginal0ebe86c2aa149023011d5c698673811627439e8c)): ?>
<?php $component = $__componentOriginal0ebe86c2aa149023011d5c698673811627439e8c; ?>
<?php unset($__componentOriginal0ebe86c2aa149023011d5c698673811627439e8c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/components/session-alerts.blade.php ENDPATH**/ ?>