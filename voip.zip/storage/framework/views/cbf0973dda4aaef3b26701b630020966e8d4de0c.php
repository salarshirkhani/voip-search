<li class="breadcrumb-item <?php if(Route::current()->getName() == $route): ?> active <?php endif; ?>">
    <?php if(Route::current()->getName() != $route): ?><a href="<?php echo e(route($route, $routeParam)); ?>"><?php echo e($title); ?></a>
    <?php else: ?> <?php echo e($title); ?>

    <?php endif; ?>
</li>
<?php /**PATH C:\Users\salar shirkhani work\Desktop\ahmadian\voip\resources\views/components/dashboard/breadcrumb-item.blade.php ENDPATH**/ ?>