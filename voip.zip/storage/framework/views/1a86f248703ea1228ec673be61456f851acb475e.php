<div class="form-row">
     <?php if (isset($component)) { $__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\TextGroup::class, ['name' => 'title','label' => 'عنوان','model' => $model ?? null,'width' => 'col-md-8']); ?>
<?php $component->withName('text-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44)): ?>
<?php $component = $__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44; ?>
<?php unset($__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\TextGroup::class, ['name' => 'priority','label' => 'اولویت','model' => $model ?? null,'width' => 'col-md-4']); ?>
<?php $component->withName('text-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44)): ?>
<?php $component = $__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44; ?>
<?php unset($__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>
 <?php if (isset($component)) { $__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\TextGroup::class, ['name' => 'url','label' => 'URL','model' => $model ?? null]); ?>
<?php $component->withName('text-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44)): ?>
<?php $component = $__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44; ?>
<?php unset($__componentOriginal81fa383b615a0dd4d1b9863b952ced6c9e720d44); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($component)) { $__componentOriginal3b9f564f42e473fbac8c7abc46fa6bde9d060af7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\FileGroup::class, ['name' => 'image','label' => 'تصویر']); ?>
<?php $component->withName('file-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3b9f564f42e473fbac8c7abc46fa6bde9d060af7)): ?>
<?php $component = $__componentOriginal3b9f564f42e473fbac8c7abc46fa6bde9d060af7; ?>
<?php unset($__componentOriginal3b9f564f42e473fbac8c7abc46fa6bde9d060af7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/dashboard/admin/slider-items/details-form.blade.php ENDPATH**/ ?>