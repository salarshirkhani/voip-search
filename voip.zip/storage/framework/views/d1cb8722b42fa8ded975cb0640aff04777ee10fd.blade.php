<div {{ $attributes->merge(['class' => 'card-header']) }}>
    <h3 class="card-title">{{ $slot }}</h3>
    {{ $down ?? '' }}
</div>