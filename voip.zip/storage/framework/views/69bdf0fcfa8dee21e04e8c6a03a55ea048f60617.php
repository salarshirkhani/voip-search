 <?php if (isset($component)) { $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\SidebarItem::class, ['title' => 'داشبورد','icon' => 'fas fa-tachometer-alt','route' => 'dashboard.admin.index']); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586)): ?>
<?php $component = $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586; ?>
<?php unset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($component)) { $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\SidebarItem::class, ['title' => 'افزودن شماره','icon' => 'fas fa-plus','route' => 'dashboard.admin.voip.create']); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586)): ?>
<?php $component = $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586; ?>
<?php unset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($component)) { $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\SidebarItem::class, ['title' => 'مدیریت شماره ها','icon' => 'fas fa-tasks','route' => 'dashboard.admin.voip.manage']); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586)): ?>
<?php $component = $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586; ?>
<?php unset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
 <?php if (isset($component)) { $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\SidebarItem::class, ['title' => 'مدیریت کاربران','icon' => 'fas fa-tasks','route' => 'dashboard.admin.users.index']); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586)): ?>
<?php $component = $__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586; ?>
<?php unset($__componentOriginal4d0d710054ed8c509030bc4c831b4f016035c586); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Users\salar shirkhani work\Desktop\ahmadian\voip\resources\views/dashboard/admin/sidebar.blade.php ENDPATH**/ ?>