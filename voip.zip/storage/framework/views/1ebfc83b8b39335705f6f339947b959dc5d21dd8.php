<div class="form-group <?php echo e($width); ?>">
    <label for="input_<?php echo e($name); ?>"><?php echo e($label); ?></label>
    <textarea <?php echo e($attributes->merge([
        'id' => "input_$name",
        'name' => $name,
        'class' => 'form-control' . ($errors->has($name) ? ' is-invalid' : '')
    ])); ?>><?php echo e($value); ?></textarea>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/components/form/textarea-group.blade.php ENDPATH**/ ?>