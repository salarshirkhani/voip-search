<div <?php echo e($attributes->merge(["class" => "card" . (!empty($type) ? " card-$type" : "")])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\salar shirkhani work\Desktop\ahmadian\voip\resources\views/components/dashboard/card.blade.php ENDPATH**/ ?>