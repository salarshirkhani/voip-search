
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('dashboard.' . Auth::user()->type . '.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('hierarchy'); ?>
     <?php if (isset($component)) { $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\BreadcrumbItem::class, ['title' => 'داشبورد','route' => 'dashboard.index']); ?>
<?php $component->withName('breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6)): ?>
<?php $component = $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6; ?>
<?php unset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\BreadcrumbItem::class, ['title' => 'مشاهده پکیج‌ها','route' => 'dashboard.plans.index']); ?>
<?php $component->withName('breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6)): ?>
<?php $component = $__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6; ?>
<?php unset($__componentOriginal5e94da915e83043bb21eaa1cca83b12b8c6bb0f6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.session-alerts','data' => []]); ?>
<?php $component->withName('session-alerts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($component)) { $__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Card::class, []); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php if (isset($component)) { $__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardHeader::class, []); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>بسته‌ها <?php if (isset($__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c)): ?>
<?php $component = $__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c; ?>
<?php unset($__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardBody::class, []); ?>
<?php $component->withName('card-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="row">
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                             <?php if (isset($component)) { $__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\Card::class, ['type' => 'success']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                 <?php if (isset($component)) { $__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardHeader::class, []); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                                    <?php echo e($plan->name); ?>

                                     <?php $__env->slot('down'); ?> 
                                        <h6 class="card-subtitle mt-2">
                                            <?php echo e($plan->price); ?> تومان
                                        </h6>
                                     <?php $__env->endSlot(); ?>
                                 <?php if (isset($__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c)): ?>
<?php $component = $__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c; ?>
<?php unset($__componentOriginalcd3db4981e341f58691620142a63228d53f18b5c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $plan->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            <?php echo e($feature->description); ?>

                                            <?php if(in_array($feature->value, ['Y', 'N'])): ?>
                                                <span class="float-right">
                                                    <i class="fas fa-<?php echo e($feature->value == 'true' ? 'check' : 'times'); ?>"></i>
                                                </span>
                                            <?php else: ?>
                                                <span class="float-right"><?php echo e($feature->value); ?></span>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                 <?php if (isset($component)) { $__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard\CardFooter::class, []); ?>
<?php $component->withName('card-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                    <form method="POST" action="<?php echo e(route('dashboard.plans.subscribe', $plan)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-outline-primary">سفارش</button>
                                    </form>
                                 <?php if (isset($__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d)): ?>
<?php $component = $__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d; ?>
<?php unset($__componentOriginald56cd687bf5301a61bcc07ca4ae6cf6185c8322d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff)): ?>
<?php $component = $__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff; ?>
<?php unset($__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
             <?php if (isset($__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225)): ?>
<?php $component = $__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225; ?>
<?php unset($__componentOriginale7c70c223581c7fb87e5339ae3a6066f4029d225); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff)): ?>
<?php $component = $__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff; ?>
<?php unset($__componentOriginalc1f54172c85f6c15c5458fb7202a71899eae68ff); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pol\b2b\resources\views/dashboard/plans/index.blade.php ENDPATH**/ ?>