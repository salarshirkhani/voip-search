@extends('layouts.content')
@section('index')
<div class="container"  style="margin-top: 120px;">
    <div class="row">
      <div class="col-3">
        <h3 style="margin-top: 80px;text-align: center;">شماره انتخاب شده</h3>
        <h3 class="yournum"><?php echo $number; ?></h3>
      </div>
    </div>
  </div>
  <div class="container">
    
    <div class="row">
      <div class="col-md-6 col-lg-6 col-sm-12">
        <img src="{{asset('img/undraw_sign_in_e6hj.png')}}" alt="" width="100%">
      </div>
      <div class="col-md-6 col-lg-6 col-sm-12">
        <div class="userdet" style="display: block; margin-left: auto; margin-right: auto;">
          <h4>مشخصات خود را وارد کنید</h4>
          <form class="sform" action="">
            <div class="row">
              <div class="col-md-6 col-sm-12 col-lg-6">
                <label for="lname">نام خانوادگی</label><br>
                <input type="text" placeholder="محمدی" id="lname"><br>
              </div>
              <div class="col-md-6 col-sm-12 col-lg-6">
                <label for="fname" style="text-align: right;">نام</label><br>
                <input type="text" placeholder="محمد" id="fname">
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 col-sm-12 col-lg-6">
                <label for="phonenum">تلفن همراه</label><br>
                <input type="tel" id="phonenum" placeholder="09123456789"><br>
              </div>
              <div class="col-md-6 col-sm-12 col-lg-6">
                <label for="email">ایمیل</label><br>
                <input type="email" id="email" placeholder="info@example.com"><br>
              </div>
              <input type="submit" value="پرداخت">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  @endsection