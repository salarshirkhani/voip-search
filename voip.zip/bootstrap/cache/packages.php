<?php return array (
  'andrey-helldar/laravel-lang-publisher' => 
  array (
    'providers' => 
    array (
      0 => 'Helldar\\LaravelLangPublisher\\ServiceProvider',
    ),
  ),
  'andrey-helldar/support' => 
  array (
    'providers' => 
    array (
      0 => 'Helldar\\Support\\ServiceProvider',
    ),
  ),
  'barryvdh/laravel-ide-helper' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\LaravelIdeHelper\\IdeHelperServiceProvider',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'felixkiss/uniquewith-validator' => 
  array (
    'providers' => 
    array (
      0 => 'Felixkiss\\UniqueWithValidator\\ServiceProvider',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'laravel/telescope' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Telescope\\TelescopeServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/ui' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Ui\\UiServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'rinvex/laravel-subscriptions' => 
  array (
    'providers' => 
    array (
      0 => 'Rinvex\\Subscriptions\\Providers\\SubscriptionsServiceProvider',
    ),
  ),
  'rinvex/laravel-support' => 
  array (
    'providers' => 
    array (
      0 => 'Rinvex\\Support\\Providers\\SupportServiceProvider',
    ),
  ),
  'shetabit/payment' => 
  array (
    'providers' => 
    array (
      0 => 'Shetabit\\Payment\\Provider\\PaymentServiceProvider',
    ),
    'aliases' => 
    array (
      'Payment' => 'Shetabit\\Payment\\Facade\\Payment',
    ),
  ),
  'spatie/laravel-schemaless-attributes' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\SchemalessAttributes\\SchemalessAttributesServiceProvider',
    ),
  ),
  'spatie/laravel-translatable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Translatable\\TranslatableServiceProvider',
    ),
  ),
);