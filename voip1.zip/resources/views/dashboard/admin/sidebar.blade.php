<x-sidebar-item title="داشبورد" icon="fas fa-tachometer-alt" route="dashboard.admin.index" />
<x-sidebar-item title="افزودن شماره" icon="fas fa-plus" route="dashboard.admin.voip.create" />
<x-sidebar-item title="مدیریت شماره ها" icon="fas fa-tasks" route="dashboard.admin.voip.manage" />
<x-sidebar-item title="مدیریت کاربران" icon="fas fa-tasks" route="dashboard.admin.users.index" />
